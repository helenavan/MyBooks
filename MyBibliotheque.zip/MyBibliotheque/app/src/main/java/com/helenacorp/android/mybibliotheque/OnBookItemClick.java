package com.helenacorp.android.mybibliotheque;

/**
 * Created by helena on 11/01/2018.
 */

public interface OnBookItemClick {
    void onBookItemClick(String isbnData);
}
