package com.helenacorp.android.mybibliotheque;

import java.util.List;

/**
 * Created by helena on 15/01/2018.
 */

public class Results {
    int totalItems;
    List<Result> items;

    public int getTotalItems() {
        return totalItems;
    }

    public List<Result> getItems() {
        return items;
    }
}
